import numpy as np

def generate_code(bit,h,num):
    space = []
    hashcode=[]
    str1='{:0'+str(bit)+'b}'   
    for i in range(0,2**bit): 
            space.append(i)
    #print(space[0])
    hashcode.append(space[0])
    l=len(hashcode)
    hashcode =hs(hashcode,space,h)
    #print(hashcode)
    hashcode=hashcode1(hashcode,bit)  
    hashcode=hashcode[:num]
    return np.array(hashcode)
def hs(hashcode,space,h):
    for i in space:
        #print(hashcode)
        k=0
        for j in hashcode:
            k+=1
            #print(k)
            if bin(i^j).count('1') <h :
                break
            if k==len(hashcode):
               # print(bin(i^j).count('1'))
                hashcode.append(i)
                #print(i)
                break

    return(hashcode)
def hashcode1(hashcode,bit):
    str1='{:0'+str(bit)+'b}'
    
    code =[]
    
    for i in hashcode:
        b=str1.format(i)
        code.append(list(map(int, b)))
        
    return code
    
code =generate_code(12,6,10)
print(len(code))
print(code[0])
print(code[1])
#print(map(int, str(634)))