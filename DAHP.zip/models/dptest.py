import torch.nn as nn
import torch
from torchvision import models
from .eca_module import eca_layer
from .DAattention import PAM_Module
from .DAattention import CAM_Module
import math

class AlexNet(nn.Module):
  def __init__(self, hash_bit):
    super(AlexNet, self).__init__()
    model_alexnet = models.alexnet(pretrained=True)
    self.features = model_alexnet.features
    cl1 = nn.Linear(256 * 6 * 6, 4096)
    cl1.weight = model_alexnet.classifier[1].weight
    cl1.bias = model_alexnet.classifier[1].bias

    cl2 = nn.Linear(4096, 4096)
    cl2.weight = model_alexnet.classifier[4].weight
    cl2.bias = model_alexnet.classifier[4].bias
    self.classifier = nn.Sequential(
        nn.Dropout(),
        cl1,
        nn.ReLU(inplace=True),
        nn.Dropout(),
        cl2,
        nn.ReLU(inplace=True),
        nn.Linear(4096, hash_bit),
    )

  def forward(self, x):
    x = self.features(x)
    x = x.view(x.size(0), 256 * 6 * 6)
    x = self.classifier(x)
    return x
########################################################################################
class Resnet50(nn.Module):
  def __init__(self, hash_bit):
    super( Resnet50, self).__init__()
    model_resnet50 = models.resnet50(pretrained=True)
    self.features =  model_resnet50
    self.fclayer = nn.Linear(1000,  hash_bit)
    if isinstance(self.fclayer, nn.Linear):
        nn.init.normal_(self.fclayer.weight, 0, 0.01)
        nn.init.zeros_(self.fclayer.bias)

  def forward(self, x):
    x = self.features(x)
    x = self.fclayer(x)
    return x

###########################################################################
class Resnet50_eca(nn.Module):
  def __init__(self, hash_bit):
    super( Resnet50_eca, self).__init__()
    model_resnet50 = models.resnet50(pretrained=True)
    self.features0 = nn.Sequential(model_resnet50.conv1,
                                  model_resnet50.bn1,
                                  model_resnet50.relu,
                                  model_resnet50.maxpool,
                                  model_resnet50.layer1,
                                  model_resnet50.layer2,
                                  model_resnet50.layer3,
                                  model_resnet50.layer4,
                                  model_resnet50.avgpool,
                                  )
    self.eca =  eca_layer()
    self.features1 =  model_resnet50.fc
    self.fclayer = nn.Linear(1000,  hash_bit)

    if isinstance(self.fclayer, nn.Linear):
        nn.init.normal_(self.fclayer.weight, 0, 0.01)
        nn.init.zeros_(self.fclayer.bias)
    if isinstance(self.eca.conv, nn.Conv1d):
            nn.init.kaiming_normal_(self.eca.conv.weight, mode='fan_out', nonlinearity='relu')
  def forward(self, x):
    x1 = self.features0(x)
    x2 = torch.flatten(x1, 1)
    x3 = self.eca(x1)
    x4 = torch.flatten(x3, 1)
    x5 = x2 + x4
    x6 = self.features1(x5)
    x = self.fclayer(x6)
    return x




############################################################################


##############################################################################################
class Resnet18(nn.Module):
  def __init__(self, hash_bit):
    super( Resnet18, self).__init__()
    model_resnet18 = models.resnet18(pretrained=True)
    self.features =  model_resnet18
    self.fclayer = nn.Linear(1000,  hash_bit)
    if isinstance(self.fclayer, nn.Linear):
        nn.init.normal_(self.fclayer.weight, 0, 0.01)
        nn.init.zeros_(self.fclayer.bias)

  def forward(self, x):
    x = self.features(x)
    x = self.fclayer(x)
    return x


###########################################################################
class Resnet18_eca(nn.Module):
  def __init__(self, hash_bit):
    super( Resnet18_eca, self).__init__()
    model_resnet18 = models.resnet18(pretrained=True)
    self.features0 = nn.Sequential(model_resnet18.conv1,
                                  model_resnet18.bn1,
                                  model_resnet18.relu,
                                  model_resnet18.maxpool,
                                  model_resnet18.layer1,
                                  model_resnet18.layer2,
                                  model_resnet18.layer3,
                                  model_resnet18.layer4,
                                  model_resnet18.avgpool,
                                  )
    self.eca =  eca_layer()
    self.features1 =  model_resnet18.fc
    self.fclayer = nn.Linear(1000,  hash_bit)

    if isinstance(self.fclayer, nn.Linear):
        nn.init.normal_(self.fclayer.weight, 0, 0.01)
        nn.init.zeros_(self.fclayer.bias)
    if isinstance(self.eca.conv, nn.Conv1d):
            nn.init.kaiming_normal_(self.eca.conv.weight, mode='fan_out', nonlinearity='relu')
  def forward(self, x):
    x1 = self.features0(x)
    x2 = torch.flatten(x1, 1)
    x3 = self.eca(x1)
    x4 = torch.flatten(x3, 1)
    x5 = x2 + 0.2*x4
    x6 = self.features1(x5)
    x = self.fclayer(x6)
    return x

####################################
class Resnet18_DA(nn.Module):
  def __init__(self, hash_bit):
    super( Resnet18_DA, self).__init__()
    model_resnet18 = models.resnet18(pretrained=True)
    self.features0 = nn.Sequential(model_resnet18.conv1,
                                  model_resnet18.bn1,
                                  model_resnet18.relu,
                                  model_resnet18.maxpool,
                                  model_resnet18.layer1,
                                  model_resnet18.layer2,
                                  model_resnet18.layer3,
                                  model_resnet18.layer4,
                                  model_resnet18.avgpool,
                                  )
    self.daattention = DANetHead_simple(in_channels=512, out_channels=512)
    self.features1 =  model_resnet18.fc
    self.fclayer = nn.Linear(1000,  hash_bit)

    if isinstance(self.fclayer, nn.Linear):
        nn.init.normal_(self.fclayer.weight, 0, 0.01)
        nn.init.zeros_(self.fclayer.bias)

  def forward(self, x):
    x1 = self.features0(x)
    x2 = torch.flatten(x1, 1)
    x3 =  self.daattention(x1)
    x4 = torch.flatten(x3, 1)
    x5 = x2 + x4
    x6 = self.features1(x5)
    x = self.fclayer(x6)
    return x

#####################################
class Resnet18_DA1(nn.Module):
  def __init__(self, hash_bit):
    super( Resnet18_DA1, self).__init__()
    model_resnet18 = models.resnet18(pretrained=True)
    self.features0 = nn.Sequential(model_resnet18.conv1,
                                  model_resnet18.bn1,
                                  model_resnet18.relu,
                                  model_resnet18.maxpool,
                                  model_resnet18.layer1,
                                  model_resnet18.layer2,
                                  model_resnet18.layer3,
                                  model_resnet18.layer4,
                                  model_resnet18.avgpool,
                                  )
    self.daattention = DANetHead_simple(in_channels=512, out_channels=512)
    self.features1 =  model_resnet18.fc
    self.fclayer = nn.Linear(1000,  hash_bit)

    if isinstance(self.fclayer, nn.Linear):
        nn.init.normal_(self.fclayer.weight, 0, 0.01)
        nn.init.zeros_(self.fclayer.bias)



  def forward(self, x):
    x1 = self.features0(x)
    # x2 = torch.flatten(x1, 1)
    x3 =  self.daattention(x1)
    x4 = torch.flatten(x3, 1)
    # x5 = x2 + 0.2*x4
    x6 = self.features1(x4)
    x = self.fclayer(x6)
    return x




########################################

class DANetHead_simple(nn.Module):
    def __init__(self, in_channels, out_channels, norm_layer=nn.BatchNorm2d):
        super(DANetHead_simple, self).__init__()
        inter_channels = in_channels // 4
        self.sa = PAM_Module(inter_channels)
        self.sc = CAM_Module(inter_channels)
        self.conv5a = nn.Conv2d(in_channels, inter_channels, 3, padding=1, bias=False)
        self.conv8 = nn.Sequential(nn.Dropout2d(0.1, False), nn.Conv2d(inter_channels, out_channels, 1))

    def forward(self, x):
        x = self.conv5a(x)
        sa_feat = self.sa(x)
        sc_feat = self.sc(x)
        feat_sum = sa_feat+sc_feat
        sasc_output = self.conv8(feat_sum)
        output = sasc_output

        return output

