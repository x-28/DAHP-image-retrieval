import torch.nn as nn
import torch
from torchvision import models
from .DAattention import PAM_Module
from .DAattention import CAM_Module
import math
# import torch.utils.model_zoo as model_zoo
from .eca_module import eca_layer
# https://github.com/jiangqy/DPSH-pytorch/blob/master/CNN_model.py

class AlexNet(nn.Module):
  def __init__(self, hash_bit):
    super(AlexNet, self).__init__()
    model_alexnet = models.alexnet(pretrained=True)
    self.features = model_alexnet.features
    cl1 = nn.Linear(256 * 6 * 6, 4096)
    cl1.weight = model_alexnet.classifier[1].weight
    cl1.bias = model_alexnet.classifier[1].bias

    cl2 = nn.Linear(4096, 4096)
    cl2.weight = model_alexnet.classifier[4].weight
    cl2.bias = model_alexnet.classifier[4].bias
    self.classifier = nn.Sequential(
        nn.Dropout(),
        cl1,
        nn.ReLU(inplace=True),
        nn.Dropout(),
        cl2,
        nn.ReLU(inplace=True),
        nn.Linear(4096, hash_bit),
    )

  def forward(self, x):
    x = self.features(x)
    x = x.view(x.size(0), 256 * 6 * 6)
    x = self.classifier(x)
    return x

#################################################################
class AlexNet_PReLU(nn.Module):
  def __init__(self, hash_bit):
    super(AlexNet_PReLU, self).__init__()
    model_alexnet = models.alexnet(pretrained=True)
    self.features = nn.Sequential(
        model_alexnet.features[0],
        nn.PReLU(num_parameters=1, init=0.25),
        model_alexnet.features[2],
        model_alexnet.features[3],
        nn.PReLU(num_parameters=1, init=0.25),
        model_alexnet.features[5],
        model_alexnet.features[6],
       nn.PReLU(num_parameters=1, init=0.25),
        model_alexnet.features[8],
        nn.PReLU(num_parameters=1, init=0.25),
        model_alexnet.features[10],
        nn.PReLU(num_parameters=1, init=0.25),
        model_alexnet.features[12],
    )
    # self.features = model_alexnet.features
    cl1 = nn.Linear(256 * 6 * 6, 4096)
    cl1.weight = model_alexnet.classifier[1].weight
    cl1.bias = model_alexnet.classifier[1].bias

    cl2 = nn.Linear(4096, 4096)
    cl2.weight = model_alexnet.classifier[4].weight
    cl2.bias = model_alexnet.classifier[4].bias
    self.classifier = nn.Sequential(
        nn.Dropout(),
        cl1,
        # nn.PReLU(num_parameters=1, init=0.25),
        nn.ReLU(inplace=True),
        nn.Dropout(),
        cl2,
        # nn.PReLU(num_parameters=1, init=0.25),
        nn.ReLU(inplace=True),
        nn.Linear(4096, hash_bit),
    )
  def forward(self, x):
    x = self.features(x)
    x = x.view(x.size(0), 256 * 6 * 6)
    x = self.classifier(x)
    return x
#######################################################  2020-07-28
class AlexNet_inattention(nn.Module):

    def __init__(self, hash_bit):
        super( AlexNet_inattention, self).__init__()
        model_alexnet = models.alexnet(pretrained=True)
        self.features = model_alexnet.features
        self.eca =  eca_layer()
        cl1 = nn.Linear(256 * 6 * 6, 4096)
        cl1.weight = model_alexnet.classifier[1].weight
        cl1.bias = model_alexnet.classifier[1].bias

        cl2 = nn.Linear(4096, 4096)
        cl2.weight = model_alexnet.classifier[4].weight
        cl2.bias = model_alexnet.classifier[4].bias
        self.classifier = nn.Sequential(
            nn.Dropout(),
            cl1,
            nn.ReLU(inplace=True),
            nn.Dropout(),
            cl2,
            nn.ReLU(inplace=True),
            nn.Linear(4096, hash_bit),
        )

    def forward(self, x):
        x1 = self.features(x)
        x = self.eca(x1)
        x = x1 + 0.5*x
        x = x.view(x.size(0), 256 * 6 * 6)
        x = self.classifier(x)
        return x

###########################################################
class AlexNet_DAattnetion_simple(nn.Module):
  def __init__(self, hash_bit):
    super(AlexNet_DAattnetion_simple, self).__init__()
    model_alexnet = models.alexnet(pretrained=True)
    self.features = model_alexnet.features
    cl1 = nn.Linear(256 * 6 * 6, 4096)
    cl1.weight = model_alexnet.classifier[1].weight
    cl1.bias = model_alexnet.classifier[1].bias

    cl2 = nn.Linear(4096, 4096)
    cl2.weight = model_alexnet.classifier[4].weight
    cl2.bias = model_alexnet.classifier[4].bias
    self.daattention = DANetHead_simple(in_channels=256, out_channels=256)
    self.classifier = nn.Sequential(
        # nn.Dropout(),
        cl1,
        nn.ReLU(inplace=True),
        nn.Dropout(),
        cl2,
        nn.ReLU(inplace=True),
        nn.Linear(4096, hash_bit),
    )

  def forward(self, x):
    x1 = self.features(x)
    x = self.daattention(x1)
    x = x + x1
    x = x.view(x.size(0), 256 * 6 * 6)
    x = self.classifier(x)
    return x



class DANetHead_simple(nn.Module):
    def __init__(self, in_channels, out_channels, norm_layer=nn.BatchNorm2d):
        super(DANetHead_simple, self).__init__()
        inter_channels = in_channels // 4
        self.sa = PAM_Module(inter_channels)
        self.sc = CAM_Module(inter_channels)
        self.conv5a = nn.Sequential(nn.Conv2d(in_channels, inter_channels, 3, padding=1, bias=False))
        self.conv8 = nn.Sequential(nn.Dropout2d(0.1, False), nn.Conv2d(inter_channels, out_channels, 1))

    def forward(self, x):
        x = self.conv5a(x)
        sa_feat = self.sa(x)
        sc_feat = self.sc(x)
        feat_sum = sa_feat+sa_feat
        sasc_output = self.conv8(feat_sum)
        output = sasc_output

        return output

###########################################################2020-07-29

class AlexNet_DAattnetion(nn.Module):
  def __init__(self, hash_bit):
    super(AlexNet_DAattnetion, self).__init__()
    model_alexnet = models.alexnet(pretrained=True)
    self.features = model_alexnet.features
    cl1 = nn.Linear(256 * 6 * 6, 4096)
    cl1.weight = model_alexnet.classifier[1].weight
    cl1.bias = model_alexnet.classifier[1].bias

    cl2 = nn.Linear(4096, 4096)
    cl2.weight = model_alexnet.classifier[4].weight
    cl2.bias = model_alexnet.classifier[4].bias
    self.daattention = DANetHead(in_channels=256, out_channels=256)
    self.classifier = nn.Sequential(
        nn.Dropout(),
        cl1,
        nn.ReLU(inplace=True),
        nn.Dropout(),
        cl2,
        nn.ReLU(inplace=True),
        nn.Linear(4096, hash_bit),
    )

  def forward(self, x):
    x = self.features(x)
    x = self.daattention(x)
    x = x[0].view(x[0].size(0), 256 * 6 * 6)
    x = self.classifier(x)
    return x



class DANetHead(nn.Module):
    def __init__(self, in_channels, out_channels, norm_layer=nn.BatchNorm2d):
        super(DANetHead, self).__init__()
        inter_channels = in_channels // 4
        self.conv5a = nn.Sequential(nn.Conv2d(in_channels, inter_channels, 3, padding=1, bias=False),
                                   norm_layer(inter_channels),
                                   nn.ReLU())

        self.conv5c = nn.Sequential(nn.Conv2d(in_channels, inter_channels, 3, padding=1, bias=False),
                                   norm_layer(inter_channels),
                                   nn.ReLU())

        self.sa = PAM_Module(inter_channels)
        self.sc = CAM_Module(inter_channels)
        self.conv51 = nn.Sequential(nn.Conv2d(inter_channels, inter_channels, 3, padding=1, bias=False),
                                   norm_layer(inter_channels),
                                   nn.ReLU())
        self.conv52 = nn.Sequential(nn.Conv2d(inter_channels, inter_channels, 3, padding=1, bias=False),
                                   norm_layer(inter_channels),
                                   nn.ReLU())

        self.conv6 = nn.Sequential(nn.Dropout2d(0.1, False), nn.Conv2d(inter_channels, out_channels, 1))
        self.conv7 = nn.Sequential(nn.Dropout2d(0.1, False), nn.Conv2d(inter_channels, out_channels, 1))

        self.conv8 = nn.Sequential(nn.Dropout2d(0.1, False), nn.Conv2d(inter_channels, out_channels, 1))

    def forward(self, x):
        feat1 = self.conv5a(x)
        sa_feat = self.sa(feat1)
        sa_conv = self.conv51(sa_feat)
        sa_output = self.conv6(sa_conv)

        feat2 = self.conv5c(x)
        sc_feat = self.sc(feat2)
        sc_conv = self.conv52(sc_feat)
        sc_output = self.conv7(sc_conv)

        feat_sum = sa_conv+sc_conv

        sasc_output = self.conv8(feat_sum)

        output = [sasc_output]
        output.append(sa_output)
        output.append(sc_output)
        return tuple(output)


##############################################################
class AlexNet_xuezhang_attention(nn.Module):
    def __init__(self,  hash_bit):
        super(AlexNet_xuezhang_attention, self).__init__()

        #self.Conv = nn.Conv2d(3, 64, kernel_size=11, stride=4, padding=2)
        self.bn1 = nn.BatchNorm2d(64)
        self.ca1 = ChannelAttention(64)
        self.sa1 = SpatialAttention()
        self.cov1 = nn.Conv2d(3, 64, kernel_size=11, stride=4, padding=2)
        self.v = torch.nn.Parameter(nn.init.kaiming_normal_(torch.empty(100, 64,1,1), mode='fan_out', nonlinearity='relu'))
        self.features1 = nn.Sequential(
            #nn.Conv2d(3, 64, kernel_size=11, stride=4, padding=2),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
            )
        self.cov2 = nn.Conv2d(64, 192, kernel_size=5, padding=2)
        self.bn2 = nn.BatchNorm2d(192)
        self.ca2 = ChannelAttention(192)
        self.sa2 = SpatialAttention()

        self.features2 = nn.Sequential(
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
            )
        self.cov3 = nn.Conv2d(192, 384, kernel_size=3, padding=1)
        self.bn3 = nn.BatchNorm2d(384)
        self.ca3 = ChannelAttention(384)
        self.sa3 = SpatialAttention()

        self.features3 = nn.Sequential(
            nn.ReLU(inplace=True),
            nn.Conv2d(384, 256, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
        )
        self.avgpool = nn.AdaptiveAvgPool2d((6, 6))
        self.classifier = nn.Sequential(
            nn.Dropout(),
            nn.Linear(256 * 6 * 6, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Linear(4096,  hash_bit),
        )

    def forward(self, x):
        x = self.cov1(x)
        x = self.ca1(x) * x
        x = self.sa1(x) * x
        x = self.bn1(x)
        x = self.features1(x)
        x = self.cov2(x)
        #x = self.ca2(x) * x
        #x = self.sa2(x) * x
        #x = self.bn2(x)
        x = self.features2(x)
        x = self.cov3(x)
        #x = self.ca3(x) * x
        #x = self.sa3(x) * x
        #x = self.bn3(x)
        x = self.features3(x)
        x = self.avgpool(x)
        x = x.view(x.size(0), 256 * 6 * 6)
        x = self.classifier(x)
        return x


class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc1   = nn.Conv2d(in_planes, in_planes // 16, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2   = nn.Conv2d(in_planes // 16, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = avg_out + max_out
        return self.sigmoid(out)

class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)

##############################################################################
######################    Resnet 18 、34、50、101、 152    ##########################################


def conv3x3(in_planes, out_planes, stride=1):
    """3x3 convolution with padding"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride,
                     padding=1, bias=False)


class ECABasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, downsample=None, k_size=3):
        super(ECABasicBlock, self).__init__()
        self.conv1 = conv3x3(inplanes, planes, stride)
        self.bn1 = nn.BatchNorm2d(planes)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = conv3x3(planes, planes, 1)
        self.bn2 = nn.BatchNorm2d(planes)
        self.eca = eca_layer(k_size)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        residual = x
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.eca(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out += residual
        out = self.relu(out)

        return out


class ECABottleneck(nn.Module):
    expansion = 4

    def __init__(self, inplanes, planes, stride=1, downsample=None, k_size=3):
        super(ECABottleneck, self).__init__()
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=stride,
                               padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.conv3 = nn.Conv2d(planes, planes * 4, kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm2d(planes * 4)
        self.relu = nn.ReLU(inplace=True)
        self.eca = eca_layer(planes * 4, k_size)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)
        out = self.eca(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out += residual
        out = self.relu(out)

        return out


class ResNet(nn.Module):

    def __init__(self, block, layers, num_classes=1000, k_size=[3, 3, 3, 3]):
        self.inplanes = 64
        super(ResNet, self).__init__()
        self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3,
                               bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.layer1 = self._make_layer(block, 64, layers[0], int(k_size[0]))
        self.layer2 = self._make_layer(block, 128, layers[1], int(k_size[1]), stride=2)
        self.layer3 = self._make_layer(block, 256, layers[2], int(k_size[2]), stride=2)
        self.layer4 = self._make_layer(block, 512, layers[3], int(k_size[3]), stride=2)
        self.avgpool = nn.AvgPool2d(7, stride=1)
        self.fc = nn.Linear(512 * block.expansion, num_classes)

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()

    def _make_layer(self, block, planes, blocks, k_size, stride=1):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(planes * block.expansion),
            )

        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample, k_size))
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(self.inplanes, planes, k_size=k_size))

        return nn.Sequential(*layers)

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)

        return x


def eca_resnet18(num_classes=1000, k_size=[3, 3, 3, 3], pretrained=False):
    """Constructs a ResNet-18 model.

    Args:
        k_size: Adaptive selection of kernel size
        pretrained (bool): If True, returns a model pre-trained on ImageNet
        num_classes:The classes of classification
    """
    model = ResNet(ECABasicBlock, [2, 2, 2, 2], num_classes=num_classes, k_size=[3, 3, 3, 3])
    model.avgpool = nn.AdaptiveAvgPool2d(1)
    return model


def eca_resnet34(num_classes=1000, k_size=[3, 3, 3, 3], pretrained=False):
    """Constructs a ResNet-34 model.

    Args:
        k_size: Adaptive selection of kernel size
        pretrained (bool): If True, returns a model pre-trained on ImageNet
        num_classes:The classes of classification
    """
    model = ResNet(ECABasicBlock, [3, 4, 6, 3], num_classes=num_classes, k_size=k_size)
    model.avgpool = nn.AdaptiveAvgPool2d(1)
    return model


def eca_resnet50(num_classes=1000,k_size=[3, 3, 3, 3], pretrained=True):
    """Constructs a ResNet-50 model.

    Args:
        k_size: Adaptive selection of kernel size
        num_classes:The classes of classification
        pretrained (bool): If True, returns a model pre-trained on ImageNet
    """
    print("Constructing eca_resnet50......")
    model = ResNet(ECABottleneck, [3, 4, 6, 3], num_classes=num_classes, k_size=k_size)
    model.avgpool = nn.AdaptiveAvgPool2d(1)
    return model


def eca_resnet101(num_classes=1000, k_size=[3, 3, 3, 3],  pretrained=False):
    """Constructs a ResNet-101 model.

    Args:
        k_size: Adaptive selection of kernel size
        num_classes:The classes of classification
        pretrained (bool): If True, returns a model pre-trained on ImageNet
    """
    model = ResNet(ECABottleneck, [3, 4, 23, 3], num_classes=num_classes, k_size=k_size)
    model.avgpool = nn.AdaptiveAvgPool2d(1)
    return model


def eca_resnet152( num_classes=1000, k_size=[3, 3, 3, 3], pretrained=False):
    """Constructs a ResNet-152 model.

    Args:
        k_size: Adaptive selection of kernel size
        num_classes:The classes of classification
        pretrained (bool): If True, returns a model pre-trained on ImageNet
    """
    model = ResNet(ECABottleneck, [3, 8, 36, 3], num_classes=num_classes, k_size=k_size)
    model.avgpool = nn.AdaptiveAvgPool2d(1)
    return model












####################################################################################2020-07-29 0:19
class AlexNet_FReLU(nn.Module):

    def __init__(self, hash_bit):
        super( AlexNet_FReLU, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=11, stride=4, padding=2),
            FReLU(64),
            # nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
            nn.Conv2d(64, 192, kernel_size=5, padding=2),
            FReLU(192),
            # nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
            nn.Conv2d(192, 384, kernel_size=3, padding=1),
            FReLU(384),
            # nn.ReLU(inplace=True),
            nn.Conv2d(384, 256, kernel_size=3, padding=1),
            FReLU(256),
            # nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            FReLU(256),
            # nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
        )
        self.avgpool = nn.AdaptiveAvgPool2d((6, 6))
        self.classifier = nn.Sequential(
            nn.Dropout(),
            nn.Linear(256 * 6 * 6, 4096),
            nn.PReLU(num_parameters=1, init=0.25),
            # nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, 4096),
            nn.PReLU(num_parameters=1, init=0.25),
            # nn.ReLU(inplace=True),
            nn.Linear(4096, hash_bit),
        )

    def forward(self, x):
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x



class FReLU(nn.Module):
# FReLU formulation. The funnel condition has a window size of kxk. (k=3 by default)
    def __init__(self, in_channels):
        super().__init__()
        self.conv_frelu = nn.Conv2d(in_channels, in_channels, 3, 1, 1, groups=in_channels)
        self.bn_frelu = nn.BatchNorm2d(in_channels)

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm2d) and m.affine:
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, x):
        x1 = self.conv_frelu(x)
        x1 = self.bn_frelu(x1)
        x = torch.max(x, x1)
        return x


#########################################################################################




class AlexNet_fasthash(nn.Module):
  def __init__(self, hash_bit,num_class):
    super(AlexNet_fasthash, self).__init__()
    model_alexnet = models.alexnet(pretrained=True)
    self.features = model_alexnet.features
    cl1 = nn.Linear(256 * 6 * 6, 4096)
    cl1.weight = model_alexnet.classifier[1].weight
    cl1.bias = model_alexnet.classifier[1].bias

    cl2 = nn.Linear(4096, 4096)
    cl2.weight = model_alexnet.classifier[4].weight
    cl2.bias = model_alexnet.classifier[4].bias

    self.classifier = nn.Sequential(
        nn.Dropout(),
        cl1,
        nn.ReLU(inplace=True),
        nn.Dropout(),
        cl2,
        nn.ReLU(inplace=True),
        nn.Linear(4096, hash_bit),
    )
    self.tanh = nn.Tanh()
    self.linear = nn.Linear(hash_bit, num_class)
  def forward(self, x):
    x = self.features(x)
    x = x.view(x.size(0), 256 * 6 * 6)
    x = self.classifier(x)
    x = self.tanh(x)
    y = self.linear(x)
    return x,y

class AlexNet_DSDH(nn.Module):
  def __init__(self, hash_bit,num_class):
    super(AlexNet_DSDH, self).__init__()
    model_alexnet = models.alexnet(pretrained=True)
    self.features = model_alexnet.features
    cl1 = nn.Linear(256 * 6 * 6, 4096)
    cl1.weight = model_alexnet.classifier[1].weight
    cl1.bias = model_alexnet.classifier[1].bias

    cl2 = nn.Linear(4096, 4096)
    cl2.weight = model_alexnet.classifier[4].weight
    cl2.bias = model_alexnet.classifier[4].bias

    self.classifier = nn.Sequential(
        nn.Dropout(),
        cl1,
        nn.ReLU(inplace=True),
        nn.Dropout(),
        cl2,
        nn.ReLU(inplace=True),
        nn.Linear(4096, hash_bit),
    )
    self.linear = nn.Linear(hash_bit, num_class)


  def forward(self, x):
    x = self.features(x)
    x = x.view(x.size(0), 256 * 6 * 6)
    x = self.classifier(x)
    y = self.linear(x)
    return x,y

class AlexNet_DSH(nn.Module):
  def __init__(self, hash_bit):
    super(AlexNet_DSH, self).__init__()
    model_alexnet = models.alexnet(pretrained=True)
    self.features = model_alexnet.features
    cl1 = nn.Linear(256 * 6 * 6, 4096)
    cl1.weight = model_alexnet.classifier[1].weight
    cl1.bias = model_alexnet.classifier[1].bias

    cl2 = nn.Linear(4096, 4096)
    cl2.weight = model_alexnet.classifier[4].weight
    cl2.bias = model_alexnet.classifier[4].bias

    self.classifier = nn.Sequential(
        nn.Dropout(),
        cl1,
        nn.ReLU(inplace=True),
        #nn.Dropout(),
        #cl2,
        #nn.ReLU(inplace=True),
        nn.Linear(4096, hash_bit),
    )


  def forward(self, x):
    x = self.features(x)
    x = x.view(x.size(0), 256 * 6 * 6)
    x = self.classifier(x)
    return x



